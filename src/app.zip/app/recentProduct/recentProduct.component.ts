import { Component, Input } from '@angular/core';

@Component({
  selector: 'recentProduct',
  templateUrl: './recentProduct.component.html',
  styleUrls: ['./recentProduct.component.css']
})
export class RecentProduct {
    @Input() public parentData

}