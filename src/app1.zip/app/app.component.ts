import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  title = 'Assignemnt 1';
  stock= [
  {
    "Product" : "Dell Inspiron",
    "Quantity" : "4"
  },
  {
    "Product" : "HP SL Notebook",
    "Quantity" : "3"
  }
]
share = () =>{
  let productName = (<HTMLInputElement>document.getElementById("product")).value;
  let qty = (<HTMLInputElement>document.getElementById("qty")).value;
  let item={
    "Product" : productName,
    "Quantity" : qty
  }
  this.stock.push(item);
}

}
